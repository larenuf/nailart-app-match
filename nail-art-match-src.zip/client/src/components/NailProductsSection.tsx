import { Link } from "wouter";
import { ShoppingCart, ArrowRight } from "lucide-react";
import { useI18n } from "@/i18n";
import { useEffect, useState } from "react";
import { nailartbakimImage, nailartKitImage } from "./ImportedImages";

export default function NailProductsSection() {
  const { t, locale } = useI18n();
  const [timestamp, setTimestamp] = useState(Date.now());
  
  // Cache bypass için her 5 saniyede bir timestamp güncellenecek
  useEffect(() => {
    setTimestamp(Date.now());
  }, []);
  
  return (
    <div className="px-4 py-4">
      {/* Tırnak Ürünleri Satış Alanı */}
      <div className="mb-6">
        <div className="flex justify-between items-center mb-3">
          <h2 className="text-sm font-medium tracking-tight text-gray-700 dark:text-gray-300 flex items-center">
            <ShoppingCart size={14} className="text-purple-500 mr-1"/>
            {locale === 'tr' ? 'Tırnak Ürünleri' : locale === 'en' ? 'Nail Products' : 'منتجات الأظافر'}
          </h2>
          <Link href={`/shop?v=${timestamp}`} className="text-xs font-medium text-primary dark:text-pink-400 flex items-center cursor-pointer">
            {locale === 'tr' ? 'Mağazaya Git' : locale === 'en' ? 'Go to Shop' : 'الذهاب إلى المتجر'} <ArrowRight size={10} className="ml-0.5"/>
          </Link>
        </div>
        
        <div className="grid grid-cols-2 gap-3">
          {/* Tırnak Bakım Ürün 1 */}
          <Link href={`/product-category/nail-care?v=${timestamp}`} className="cursor-pointer group">
              <div className="relative overflow-hidden rounded-lg aspect-[1/1] shadow-sm transition-transform duration-300 group-hover:scale-[1.02]">
                {/* Tırnak Bakım Ürün Görseli */}
                <img 
                  src={nailartbakimImage} 
                  alt="Tırnak Bakım Ürün 1"
                  className="absolute inset-0 w-full h-full object-cover"
                  onError={(e) => {
                    // Hata durumunda fallback görünüm
                    const target = e.target as HTMLImageElement;
                    target.style.display = 'none';
                    const parent = target.parentElement;
                    if (parent) {
                      const fallback = document.createElement('div');
                      fallback.className = "absolute inset-0 bg-gradient-to-br from-pink-100 to-purple-200 opacity-90";
                      fallback.innerHTML = `
                        <div class="absolute inset-0 flex flex-col justify-center items-center">
                          <div class="w-16 h-16 bg-white rounded-full flex items-center justify-center mb-2">
                            <span class="text-3xl">💅</span>
                          </div>
                        </div>`;
                      parent.appendChild(fallback);
                    }
                  }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-70"></div>
                <div className="absolute bottom-0 left-0 p-2.5 text-white">
                  <h3 className="text-sm font-bold">💅 {locale === 'tr' ? 'Tırnak Bakım Ürün 1' : locale === 'en' ? 'Nail Care Product 1' : 'منتج العناية بالأظافر 1'}</h3>
                  <div className="flex items-center mt-1">
                    <span className="text-xs mr-2 bg-white/30 px-2 py-0.5 rounded-full backdrop-blur-sm">
                      {locale === 'tr' ? 'Özel Fiyatlar' : locale === 'en' ? 'Special Prices' : 'أسعار خاصة'}
                    </span>
                    <span className="text-xs bg-primary/80 px-2 py-0.5 rounded-full">
                      {locale === 'tr' ? '%15 İndirim' : locale === 'en' ? '15% Discount' : 'خصم ١٥٪'}
                    </span>
                  </div>
                </div>
              </div>
          </Link>
          
          {/* Nail Art Kitler */}
          <Link href={`/product-category/nail-art-kits?v=${timestamp}`} className="cursor-pointer group">
              <div className="relative overflow-hidden rounded-lg aspect-[1/1] shadow-sm transition-transform duration-300 group-hover:scale-[1.02]">
                {/* Nail Art Kit Görseli */}
                <img 
                  src={nailartKitImage} 
                  alt="Nail Art Kitler"
                  className="absolute inset-0 w-full h-full object-cover"
                  onError={(e) => {
                    // Hata durumunda fallback görünüm
                    const target = e.target as HTMLImageElement;
                    target.style.display = 'none';
                    const parent = target.parentElement;
                    if (parent) {
                      const fallback = document.createElement('div');
                      fallback.className = "absolute inset-0 bg-gradient-to-br from-purple-100 to-blue-200 opacity-90";
                      fallback.innerHTML = `
                        <div class="absolute inset-0 flex flex-col justify-center items-center">
                          <div class="w-16 h-16 bg-white rounded-full flex items-center justify-center mb-2">
                            <span class="text-3xl">✨</span>
                          </div>
                        </div>`;
                      parent.appendChild(fallback);
                    }
                  }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-70"></div>
                <div className="absolute bottom-0 left-0 p-2.5 text-white">
                  <h3 className="text-sm font-bold">✨ {locale === 'tr' ? 'Nail Art Kitler' : locale === 'en' ? 'Nail Art Kits' : 'مجموعات فن الأظافر'}</h3>
                  <div className="flex items-center mt-1">
                    <span className="text-xs mr-2 bg-white/30 px-2 py-0.5 rounded-full backdrop-blur-sm">
                      {locale === 'tr' ? 'Yeni Ürünler' : locale === 'en' ? 'New Products' : 'منتجات جديدة'}
                    </span>
                    <span className="text-xs bg-primary/80 px-2 py-0.5 rounded-full">
                      {locale === 'tr' ? '%20 İndirim' : locale === 'en' ? '20% Discount' : 'خصم ٢٠٪'}
                    </span>
                  </div>
                </div>
              </div>
          </Link>
        </div>
      </div>
    </div>
  );
}